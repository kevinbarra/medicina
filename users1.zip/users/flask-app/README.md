# examen_2parcial-SistemasDistribuidos
Examen del 2º parcial de Sistemas Distribuidos

## Instrucciones
Objetivo:
Desarrollar y dockerizar un sistema completo de seguimiento de paquetes que incluya una API en Flask, una base de datos y un servicio adicional para análisis estadísticos, además de una interfaz frontend básica.